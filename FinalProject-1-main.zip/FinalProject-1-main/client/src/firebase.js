// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAm1DK4ciBYal3kR101GQa7WJHlTGRFvLI",
  authDomain: "realtor-6545d.firebaseapp.com",
  projectId: "realtor-6545d",
  storageBucket: "realtor-6545d.appspot.com",
  messagingSenderId: "924973013646",
  appId: "1:924973013646:web:077e92b27c3629c610c7df"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);